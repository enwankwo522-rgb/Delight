import { cn } from "@/lib/utils";

/**
 * ClearCount logo: a bold shield sitting tight against the wordmark.
 */
export function BrandMark({
  className,
  size = "md",
}: {
  className?: string;
  size?: "sm" | "md" | "lg";
}) {
  const icon = size === "lg" ? "h-12 w-12" : size === "sm" ? "h-8 w-8" : "h-10 w-10";
  const text = size === "lg" ? "text-[2.5rem]" : size === "sm" ? "text-[1.375rem]" : "text-[1.625rem]";

  return (
    <span className={cn("inline-flex items-center gap-2", className)}>
      <svg
        viewBox="0 0 24 24"
        className={cn(icon, "shrink-0 text-primary")}
        fill="none"
        stroke="currentColor"
        strokeWidth={2.8}
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
      >
        <path d="M12 2.5 4 5.6v6c0 4.6 3.2 8.4 8 9.9 4.8-1.5 8-5.3 8-9.9v-6L12 2.5Z" />
        <path d="m8.6 11.9 2.4 2.4 4.4-4.6" />
      </svg>
      <span className={cn("font-display font-black tracking-tight", text)}>ClearCount</span>
    </span>
  );
}
