# Website Refresh Pro

I uploaded a file and a photo, 1 I want you to update the landing page of this website I want you to replace the front ent of the website with the picture I sent you and let everything connect to the back end as well 2 I want you to change the login  and sign up page of the website to photo I uploaded to you as well, everything should be connected to the backend page too.

Once you are done creating it verify everything to make sure it working before showing me a preview

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/b63ce83b-893f-49ad-9174-9097ec233be7).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
