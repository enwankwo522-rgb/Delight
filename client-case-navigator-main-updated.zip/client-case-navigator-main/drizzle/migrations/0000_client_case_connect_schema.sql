CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own profile" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "Users insert own profile" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE TABLE public.cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  amount_lost NUMERIC NOT NULL DEFAULT 0,
  asset_type TEXT NOT NULL DEFAULT 'Other',
  wallet_address TEXT,
  transaction_reference TEXT,
  description TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'under_review',
  amount_recovered NUMERIC NOT NULL DEFAULT 0,
  admin_note TEXT NOT NULL DEFAULT '',
  case_number BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1000000 MINVALUE 1000000 MAXVALUE 9999999),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT cases_case_number_key UNIQUE (case_number)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cases TO authenticated;
GRANT ALL ON public.cases TO service_role;
ALTER TABLE public.cases ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.set_updated_at() RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER cases_updated_at BEFORE UPDATE ON public.cases FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
REVOKE EXECUTE ON FUNCTION public.set_updated_at() FROM PUBLIC, anon, authenticated;

CREATE TYPE public.app_role AS ENUM ('admin', 'client');

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE SCHEMA IF NOT EXISTS private;
CREATE OR REPLACE FUNCTION private.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;
REVOKE ALL ON FUNCTION private.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT USAGE ON SCHEMA private TO authenticated;
GRANT EXECUTE ON FUNCTION private.has_role(uuid, public.app_role) TO authenticated;

CREATE POLICY "Users read own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins read all roles" ON public.user_roles FOR SELECT TO authenticated USING (private.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name',''), COALESCE(NEW.raw_user_meta_data->>'phone',''), COALESCE(NEW.email,''))
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, CASE WHEN lower(COALESCE(NEW.email,'')) = 'mezie707@gmail.com' THEN 'admin'::public.app_role ELSE 'client'::public.app_role END)
  ON CONFLICT (user_id, role) DO NOTHING;

  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

CREATE TABLE public.conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  last_message_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.conversations TO authenticated;
GRANT ALL ON public.conversations TO service_role;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Clients read own conversation" ON public.conversations FOR SELECT TO authenticated USING (auth.uid() = client_id);
CREATE POLICY "Clients create own conversation" ON public.conversations FOR INSERT TO authenticated WITH CHECK (auth.uid() = client_id);
CREATE POLICY "Admins read all conversations" ON public.conversations FOR SELECT TO authenticated USING (private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins update conversations" ON public.conversations FOR UPDATE TO authenticated USING (private.has_role(auth.uid(), 'admin')) WITH CHECK (private.has_role(auth.uid(), 'admin'));

CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  sender_role public.app_role NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  attachment_path TEXT,
  attachment_name TEXT,
  attachment_type TEXT,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX messages_conversation_created_idx ON public.messages (conversation_id, created_at);
GRANT SELECT, INSERT, UPDATE ON public.messages TO authenticated;
GRANT ALL ON public.messages TO service_role;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Clients read own messages" ON public.messages FOR SELECT TO authenticated
USING (EXISTS (SELECT 1 FROM public.conversations c WHERE c.id = conversation_id AND c.client_id = auth.uid()));
CREATE POLICY "Clients mark messages read" ON public.messages FOR UPDATE TO authenticated
USING (EXISTS (SELECT 1 FROM public.conversations c WHERE c.id = conversation_id AND c.client_id = auth.uid()))
WITH CHECK (EXISTS (SELECT 1 FROM public.conversations c WHERE c.id = conversation_id AND c.client_id = auth.uid()));
CREATE POLICY "Admins read all messages" ON public.messages FOR SELECT TO authenticated USING (private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins send messages" ON public.messages FOR INSERT TO authenticated
WITH CHECK (private.has_role(auth.uid(), 'admin') AND sender_id = auth.uid() AND sender_role = 'admin');
CREATE POLICY "Admins update messages" ON public.messages FOR UPDATE TO authenticated
USING (private.has_role(auth.uid(), 'admin')) WITH CHECK (private.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.touch_conversation() RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.conversations SET last_message_at = NEW.created_at WHERE id = NEW.conversation_id;
  RETURN NEW;
END; $$;
CREATE TRIGGER messages_touch_conversation AFTER INSERT ON public.messages FOR EACH ROW EXECUTE FUNCTION public.touch_conversation();
REVOKE EXECUTE ON FUNCTION public.touch_conversation() FROM PUBLIC, anon, authenticated;

ALTER TABLE public.messages REPLICA IDENTITY FULL;
ALTER TABLE public.conversations REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.conversations;

CREATE POLICY "Admins read all profiles" ON public.profiles FOR SELECT TO authenticated USING (private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins read all cases" ON public.cases FOR SELECT TO authenticated USING (private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins update all cases" ON public.cases FOR UPDATE TO authenticated USING (private.has_role(auth.uid(), 'admin')) WITH CHECK (private.has_role(auth.uid(), 'admin'));

CREATE TABLE public.case_attachments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID NOT NULL REFERENCES public.cases(id) ON DELETE CASCADE,
  storage_path TEXT NOT NULL,
  file_name TEXT NOT NULL DEFAULT '',
  file_type TEXT NOT NULL DEFAULT '',
  caption TEXT NOT NULL DEFAULT '',
  uploaded_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX case_attachments_case_idx ON public.case_attachments (case_id, created_at);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.case_attachments TO authenticated;
GRANT ALL ON public.case_attachments TO service_role;
ALTER TABLE public.case_attachments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Clients read own case attachments" ON public.case_attachments FOR SELECT TO authenticated
USING (EXISTS (SELECT 1 FROM public.cases c WHERE c.id = case_id AND c.user_id = auth.uid()));
CREATE POLICY "Admins read case attachments" ON public.case_attachments FOR SELECT TO authenticated
USING (private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins add case attachments" ON public.case_attachments FOR INSERT TO authenticated
WITH CHECK (private.has_role(auth.uid(), 'admin') AND uploaded_by = auth.uid());
CREATE POLICY "Admins update case attachments" ON public.case_attachments FOR UPDATE TO authenticated
USING (private.has_role(auth.uid(), 'admin')) WITH CHECK (private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins delete case attachments" ON public.case_attachments FOR DELETE TO authenticated
USING (private.has_role(auth.uid(), 'admin'));

CREATE POLICY "Chat files: clients read own folder" ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'chat-attachments' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Chat files: clients upload own folder" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'chat-attachments' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Chat files: admins read all" ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'chat-attachments' AND private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Chat files: admins upload all" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'chat-attachments' AND private.has_role(auth.uid(), 'admin'));

CREATE POLICY "Case files: admins manage" ON storage.objects FOR ALL TO authenticated
USING (bucket_id = 'case-attachments' AND private.has_role(auth.uid(), 'admin'))
WITH CHECK (bucket_id = 'case-attachments' AND private.has_role(auth.uid(), 'admin'));

CREATE POLICY "Case files: clients read own case files" ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'case-attachments'
  AND EXISTS (
    SELECT 1 FROM public.case_attachments a
    JOIN public.cases c ON c.id = a.case_id
    WHERE a.storage_path = storage.objects.name AND c.user_id = auth.uid()
  )
);

CREATE TABLE public.case_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID NOT NULL REFERENCES public.cases(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX case_events_case_idx ON public.case_events (case_id, created_at);
GRANT SELECT, INSERT ON public.case_events TO authenticated;
GRANT ALL ON public.case_events TO service_role;
ALTER TABLE public.case_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Clients read own case events" ON public.case_events FOR SELECT TO authenticated
USING (EXISTS (SELECT 1 FROM public.cases c WHERE c.id = case_id AND c.user_id = auth.uid()));
CREATE POLICY "Admins read case events" ON public.case_events FOR SELECT TO authenticated
USING (private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins add case events" ON public.case_events FOR INSERT TO authenticated
WITH CHECK (private.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.log_case_event() RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.case_events (case_id, status, note) VALUES (NEW.id, NEW.status, 'Case filed and received by our team.');
  ELSIF NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO public.case_events (case_id, status, note) VALUES (NEW.id, NEW.status, COALESCE(NULLIF(NEW.admin_note, ''), ''));
  END IF;
  RETURN NEW;
END; $$;
REVOKE EXECUTE ON FUNCTION public.log_case_event() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER cases_log_event_insert AFTER INSERT ON public.cases FOR EACH ROW EXECUTE FUNCTION public.log_case_event();
CREATE TRIGGER cases_log_event_update AFTER UPDATE OF status ON public.cases FOR EACH ROW EXECUTE FUNCTION public.log_case_event();

CREATE POLICY "Clients add own case attachments" ON public.case_attachments FOR INSERT TO authenticated
WITH CHECK (
  uploaded_by = auth.uid()
  AND EXISTS (SELECT 1 FROM public.cases c WHERE c.id = case_id AND c.user_id = auth.uid())
);

CREATE POLICY "Case files: clients upload own case files" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'case-attachments'
  AND EXISTS (
    SELECT 1 FROM public.cases c
    WHERE c.user_id = auth.uid() AND c.id::text = (storage.foldername(name))[1]
  )
);

ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS blocked BOOLEAN NOT NULL DEFAULT false;

CREATE POLICY "Admins update all profiles" ON public.profiles FOR UPDATE TO authenticated
  USING (private.has_role(auth.uid(), 'admin'))
  WITH CHECK (private.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.guard_profile_blocked() RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.blocked IS DISTINCT FROM OLD.blocked AND NOT private.has_role(auth.uid(), 'admin') THEN
    NEW.blocked := OLD.blocked;
  END IF;
  RETURN NEW;
END; $$;
REVOKE EXECUTE ON FUNCTION public.guard_profile_blocked() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER profiles_guard_blocked BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.guard_profile_blocked();

CREATE OR REPLACE FUNCTION private.is_blocked(_user_id UUID) RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COALESCE((SELECT blocked FROM public.profiles WHERE id = _user_id), false);
$$;
REVOKE ALL ON FUNCTION private.is_blocked(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION private.is_blocked(uuid) TO authenticated;

CREATE POLICY "Users read own cases" ON public.cases FOR SELECT TO authenticated
  USING (auth.uid() = user_id);
CREATE POLICY "Users file own cases" ON public.cases FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id AND NOT private.is_blocked(auth.uid()));
CREATE POLICY "Users update own cases" ON public.cases FOR UPDATE TO authenticated
  USING (auth.uid() = user_id AND NOT private.is_blocked(auth.uid()))
  WITH CHECK (auth.uid() = user_id AND NOT private.is_blocked(auth.uid()));
CREATE POLICY "Users delete own cases" ON public.cases FOR DELETE TO authenticated
  USING (auth.uid() = user_id);
CREATE POLICY "Admins delete cases" ON public.cases FOR DELETE TO authenticated
  USING (private.has_role(auth.uid(), 'admin'));

CREATE POLICY "Clients send own messages" ON public.messages FOR INSERT TO authenticated
WITH CHECK (
  sender_id = auth.uid() AND sender_role = 'client'
  AND NOT private.is_blocked(auth.uid())
  AND EXISTS (SELECT 1 FROM public.conversations c WHERE c.id = conversation_id AND c.client_id = auth.uid())
);